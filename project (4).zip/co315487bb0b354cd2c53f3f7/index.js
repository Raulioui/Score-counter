let localNumber = 0
let guestNumber = 0
let local1 = document.getElementById("score__numbers-1")
let local2 = document.getElementById("score__numbers-2")
let local3 = document.getElementById("score__numbers-3")
let number = document.getElementById("number")
let number2 = document.getElementById("number-2")


function add1(){
    localNumber +=  1
    number.textContent = localNumber
}
function add2(){
    localNumber +=  2
    number.textContent = localNumber
}

function add3(){
    localNumber +=  3
    number.textContent = localNumber
}


function add11(){
    guestNumber +=  1
    number2.textContent = guestNumber
}
function add22(){
    guestNumber +=  2
    number2.textContent = guestNumber
}

function add33(){
    guestNumber +=  3
    number2.textContent = guestNumber
}



function resetAll(){
    localNumber = 0
    guestNumber = 0
    number2.textContent = guestNumber
    number.textContent = localNumber
}